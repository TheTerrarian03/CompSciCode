/*
- Name: Logan Meyers
- TA: Martin (M.H.) Hundrup
- Assignment: PA 4
- Finished: 02/26/2025
- Description: Virtual Gym Calender!

- File: main.cpp
- Description: Main file, runs runApp() from FitnessAppWrapper

- I'm also realizing that I keep switching back and forth from snake_case and camelCase... oops!
-   PA3 was snake_case
-   This was camelCase...
-   Man I gotta figure this out lol
*/

#include "FitnessAppWrapper.hpp"

int main() {
	FitnessAppWrapper app;
	app.runApp();

	return 0;
}
