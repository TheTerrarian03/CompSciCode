/*
- Name: Logan Meyers
- TA: Martin Hundrup
- Date Finished: 04-09-2025
- Program: Student Absence Manager

- File: main.cpp
- What: Main entry point for the program
*/

#include "RecordManager.hpp"

int main() {
    RecordManager recMan;

    recMan.run();
}
