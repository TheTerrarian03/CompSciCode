# SFML_PA_9
Project Spec [here](https://eecs.wsu.edu/~aofallon/cpts122/progassignments/PA9.pdf)

This is our game Red ball inspired by popular game Red Ball.

Made by:
Grayson Fougere: Lab 4
Mason Nagel: Lab 3
Kenny Hussey: Lab 4
Logan Meyers: Lab 2


To move left/right is A/D and to move up is W or Space

[Youtube video](https://youtu.be/rypC-zr-mPc)
