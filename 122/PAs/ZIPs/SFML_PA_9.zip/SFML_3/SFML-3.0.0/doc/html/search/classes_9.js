var searchData=
[
  ['joystickbuttonpressed_0',['JoystickButtonPressed',['../structsf_1_1Event_1_1JoystickButtonPressed.html',1,'sf::Event']]],
  ['joystickbuttonreleased_1',['JoystickButtonReleased',['../structsf_1_1Event_1_1JoystickButtonReleased.html',1,'sf::Event']]],
  ['joystickconnected_2',['JoystickConnected',['../structsf_1_1Event_1_1JoystickConnected.html',1,'sf::Event']]],
  ['joystickdisconnected_3',['JoystickDisconnected',['../structsf_1_1Event_1_1JoystickDisconnected.html',1,'sf::Event']]],
  ['joystickmoved_4',['JoystickMoved',['../structsf_1_1Event_1_1JoystickMoved.html',1,'sf::Event']]]
];
