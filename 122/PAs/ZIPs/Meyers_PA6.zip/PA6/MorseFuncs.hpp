#pragma once

#include <iostream>

// charToID
// takes a char input
// returns an int for ID of character
int charToID(char input);

// intIDToChar
// takes an int id for input
// returns a char equivalent for the ID given
char intIDToChar(int input);
