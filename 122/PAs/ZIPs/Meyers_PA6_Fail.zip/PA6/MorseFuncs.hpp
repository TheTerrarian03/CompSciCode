#include <iostream>

// without using a map
int charToID(char input) {
    if (input > 'a') {
        std::cout << "Converting from " << input;
        input -= 32;
        std::cout << " to " << input << std::endl;
    }
    
    if (input >= 'A' && input <= 'Z') {
        return input - 'A';  // range of alphabet to 0-25
    }

    if (input >= '0' && input <= '9') {
        return input - '0' + 26; // range of numbers to 26-35
    }

    if (input == '.') return 36;
    if (input == ',') return 37;
    if (input == '?') return 38;

    else return 420; // bad number
}

// also without using a map
char intIDToChar(int input) {
    if (input >= 0 && input <= 25) {
        return (char)input + 'A';
    }

    if (input >= 26 && input <= 35) {
        return (char)(input-26) + '0';
    }

    if (input == 36) return '.';
    if (input == 37) return ',';
    if (input == 38) return '?';

    if (input == 420) return ' ';  // bad number
}

template <typename T1, typename T2>
T2 keyToValue(T1 input) {
    // T1 to char
    char c = static_cast<char>(input);  // most always char to char

    // find int id by char
    int id = charToID(c);

    // int to T2
    return static_cast<T2>(id);
}

template <typename T1, typename T2>
T1 valueToKey(T2 input) {
    // T2 to int
    int id = static_cast<int>(input);

    // find char by int id
    int c = intIDToChar(id);

    // char to T1
    return static_cast<T1>(c);
}