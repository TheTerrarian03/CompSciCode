#include "BST.hpp"

int main() {
    const BST<char, std::string> tree;

     tree.print();
}