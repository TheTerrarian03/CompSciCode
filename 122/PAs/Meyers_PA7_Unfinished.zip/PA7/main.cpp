#include "RecordManager.hpp"

int main() {
    RecordManager recMan;

    recMan.run();
}

// import: read from class list
// load: read from master csv
// store: store master list to master file csv

// master csv: all the data for a student, plus # dates and list of absence dates (strings)


// import records from file into linked list
// store value of list into master csv, with num absences and list of absence dates