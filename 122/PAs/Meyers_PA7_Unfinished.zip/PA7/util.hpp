#include <iostream>
#include <cstdlib> // for system()

// console functions
void clearConsole();
